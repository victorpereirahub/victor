console.log("Exercício 1");
console.log("");
let nicolas = "Nicolas"
console.log(nicolas);

console.log("");

console.log("Exercício 2");

let num1 = 15
let num2 = 15

let soma = num1 + num2

console.log(soma);

console.log("");

console.log("Exercício 3");

var sim = "Sim "
var nao = "Não"

var uni = sim + nao

console.log(uni);

console.log("");

console.log("Exercício 4");

let a = 10
let b = 20

console.log("a:" + a);
console.log("b:" + b);

let auxiliar = a

a = b
b = auxiliar


console.log("");

console.log("a:" + a);
console.log("b:" + b);

console.log("");

console.log("Exercício 5");

let altura = 10
let largura  = 6

let area = altura * largura

console.log("");
console.log("area: " + area);

console.log("");

console.log("Exercício 6");

let c = 20

console.log("celsius: " + c);

let fah = (c*9/5 )+32

console.log("Fahrenheit: " + fah);

console.log("");

console.log("Exercício 7");

let nume = 8
console.log("Numero: " + nume);

let quadrado = nume * nume
console.log("Ao quadrado: " + quadrado);

console.log("");

console.log("Exercício 9");

let anoDenascimento = 2008
let ano = 2024

let idade = ano - anoDenascimento

console.log("Idade: " + idade);

console.log("");

console.log("Exercício 10");


let precoOriginal = 200
console.log("Preço original: " + precoOriginal);
let porcentagemDesconto = 0.2
console.log("Desconto: " + porcentagemDesconto);

let desconto = precoOriginal * porcentagemDesconto

console.log("Desconto: " + desconto);

let precoatual = precoOriginal - desconto

console.log("Preço atual: " + precoatual);













