function inverterString(str) {
    return str.split('').reverse().join('');
}


const palavra = "JavaScript";
const inversao = inverterString(entrada);
console.log(inversao);

