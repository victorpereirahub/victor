function contarPalavras(str) {
    return str.split(" ").length;
}

console.log(contarPalavras("Java é incrivel"));