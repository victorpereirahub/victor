function encontrarMaiorNumero(array) {
    return Math.max(array);
}


const numeros = [10, 5, 20, 8, 15];
console.log(encontrarMaiorNumero(numeros)); 
